package com.punchyanimation.mixin;

import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public class PunchyHandMixin {

    @Inject(method = "applyStringAndFirstPersonTransforms", at = @At("TAIL"))
    private void injectPunchyAnimation(MatrixStack matrices, Arm arm, float swingProgress, CallbackInfo ci) {
        // Kode hanya berjalan jika tangan sedang mengayun/memukul
        if (swingProgress > 0.0F) {
            
            // Rumus sinus untuk menciptakan pergerakan melengkung yang halus
            float animationCurve = MathHelper.sin(swingProgress * (float) Math.PI);
            
            // Mengecek apakah posisi tangan di kanan atau kiri
            float sideMultiplier = arm == Arm.RIGHT ? 1.0F : -1.0F;

            // 1. MENGUBAH POSISI TANGAN (Translasi)
            // Tangan didorong ke depan (Sumbu Z) dan sedikit turun ke bawah (Sumbu Y)
            float moveX = 0.1F * animationCurve * sideMultiplier; 
            float moveY = -0.3F * animationCurve; 
            float moveZ = -0.6F * animationCurve; // Semakin besar minusnya, semakin jauh ke depan
            
            matrices.translate(moveX, moveY, moveZ);

            // 2. MENGUBAH ROTASI TANGAN (Putaran)
            // Memberikan efek pergelangan tangan menekuk ke bawah agar pukulan terasa bertenaga
            matrices.multiply(Vec3f.POSITIVE_X.getDegreesQuaternion(animationCurve * 15.0F));
            matrices.multiply(Vec3f.POSITIVE_Y.getDegreesQuaternion(sideMultiplier * animationCurve * -10.0F));
        }
    }
}
